背景图片来源：
1. map-bg.jpg - 来自 Unsplash，作者 Benjamin Voros
   - 模糊的城市地图背景
   - 分辨率：1920x1080
   - 用途：网站头部背景

2. pattern-bg.jpg - 来自 Unsplash，作者 Pawel Czerwinski
   - 抽象几何图案
   - 分辨率：1920x1080
   - 用途：功能介绍区域背景 